DELIPIT 公式サイト / Cloudflare upload package

1. Cloudflare > Workers & Pages > delipit-official > Deployments
2. 新しいデプロイ/Upload assets を選択
3. このZIPを展開し、index.html と assets フォルダをアップロード
4. 公開後、Custom Domain に delipit.jp を設定

想定構成:
- delipit.jp = 公式サイト
- app.delipit.jp = DELIPIT Webアプリ

注意:
現時点のボタンは https://app.delipit.jp/ に設定済みです。
app.delipit.jp 側の接続が完了してから実運用してください。
